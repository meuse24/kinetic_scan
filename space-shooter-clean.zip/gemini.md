# MEUSE24 Kinetic-Scan - Technical Documentation

**MEUSE24 Kinetic-Scan** is a fast-paced retro arcade shooter. The player pilots a spaceship through a dangerous asteroid field, dodging hazards and destroying procedurally generated asteroids that shatter into smaller fragments on impact. The game blends classic gameplay with a modern vector aesthetic and a dynamic scoring system.

## Tech Stack
- **Engine:** Phaser 3
- **Language:** TypeScript
- **Build Tool:** Vite
- **Architecture:** Modular Scene-based management

## Features

### 1. Rendering & Visual Style
- **Vector Wireframe Style:** All game objects (Player, Bullets, Asteroids) are rendered programmatically using Phaser Graphics.
- **Dynamic Thruster:** The player ship features a flickering, procedurally generated thruster flame.
- **Particle System:** Juicy explosions using Phaser's Particle Emitter, featuring color gradients and fading effects.
- **Parallax Starfield:** A multi-layered background with moving stars.
- **Subtle Color System:** Procedural HSL-based asteroid palette (low saturation, mid-lightness) for slate blues, anthracite, sand greys, and oxidized reds with transparent fills.
- **Title Styling:** The MEUSE24 Kinetic-Scan logo uses the Chakra Petch (700) font with a three-line hollow vector layout (transparent fill, white stroke, soft glow) and a subtle floating motion.

### 2. Gameplay Mechanics
- **Fixed Virtual Resolution:** 1000x1000 virtual resolution with "FIT" scaling for a consistent experience on all screens.
- **Procedural Asteroids:** Rocks are generated as irregular polygons with 8-12 points.
- **Splitting Logic:** Large asteroids (scale > 0.6) split into 2-3 smaller fragments upon destruction.
- **Dynamic Scoring:** Smaller asteroids are worth more points than larger ones.
- **Controls:** Multi-input support for Mouse, Touch, and Keyboard.
- **Lower Third Constraint:** The player is restricted to the bottom 33% of the screen.

### 3. Combat Mechanics
- **Platform-Specific Control:** Desktop uses manual fire via Space/left-click with a short tap buffer; mobile defaults to auto-fire.
- **Heat & Overheat:** Each shot raises heat (0–100). At 100, the ship overheats and cannot fire for 2 seconds. Heat cools down gradually when not firing.
- **Contextual UI:** The heat bar follows the ship and sits just below it for quick peripheral readability, blinking red on overheat.
- **FX & Audio:** Manual shots use a heavier laser timbre and larger muzzle flash. Overheat triggers a brief smoke puff on high-end desktops.

### 4. Systems
- **Scene Management:**
    - `MainScene`: Core gameplay loop and HUD.
    - `GameOverScene`: Score summary and restart logic.
- **Highscore System:** Persisted via `localStorage`.
- **Object Pooling:** Efficient bullet and enemy management using Phaser Groups.

### 5. Typography
- **Font:** Google Font 'Press Start 2P' for a classic 8-bit arcade aesthetic.

### 6. VFX & Juice
- **Player Death Explosion:** A massive burst of 200 particles with long lifespan (up to 2s) and high velocity to dramatize the "Game Over" moment.
- **Enhanced Camera Shake:** Dynamic camera feedback during collisions, with a particularly intense shake (duration: 500ms, intensity: 0.04) upon player destruction.
- **Delayed Scene Transition:** The game waits for the death explosion to unfold before transitioning to the Game Over screen.

### 7. Audio System
- **Synthetic Sound Generation:** All game sounds are generated programmatically using the Web Audio API, eliminating the need for external assets.
- **Classic Arcade Effects:**
    - **Laser (Shoot):** A frequency-ramped square wave for the "Pew-Pew" effect.
    - **Explosion:** Low-pass filtered white noise with exponential gain decay.
    - **Player Death:** A combination of deep crunching noise and a falling square wave for dramatic effect.
- **Autoplay Compliance:** Audio context is resumed upon the first user interaction (coin insert or start selection).

### 8. Bonus System & Homing Missiles
- **Bonus Ship (UFO):** A rare UFO (every 30-60s) moves across the screen on a sinusoidal path and emits a distinct spherical sound.
- **Power-up: Magnetic Bullets:** Shooting the UFO activates magnetic homing for 5 seconds.
- **Homing Logic:** While active, projectiles seek the nearest asteroid and steer toward it smoothly.
- **Visual & Audio Feedback:** Magnetic Bullets glow cyan. A pulsing HUD timer visualizes remaining duration.

### 9. Universal Pause System
- **Cross-Platform Controls:**
    - **Desktop:** Pause via 'P' or 'Esc'.
    - **Mobile/Tablet:** Large, touch-optimized pause button ('|| PAUSE') in the HUD.
- **Auto-Pause:** The game pauses automatically when the browser tab loses focus (blur event), ideal for phone users during interruptions.
- **Pause Mode:** A semi-transparent overlay stops gameplay and suspends synthetic audio (AudioContext suspend), while a 'RESUME' button continues play.

### 10. Power-up System & Smart Trigger Logic
The game features a highly dynamic power-up system that reacts to both player skill and in-game situations.

- **Basis Power-ups:**
    - **TRIPLE_SHOT (10s):** Fächer-Muster Schüsse.
    - **SLOW_MOTION (7s):** 50% Welt-Verlangsamung.
    - **SHIELD:** Absorbiert einen Treffer.
- **Advanced Mechanics:**
    - **EMP_WAVE:** Eine expandierende Schockwelle, die alle Asteroiden im Umkreis vaporisiert.
    - **GHOST_PHASE:** Der Spieler wird physisch immateriell (keine Kollisionen) und flackert transparent.
    - **WINGMAN_DRONES:** Zwei Drohnen begleiten den Spieler und verdoppeln die Feuerkraft.
    - **BLACK_HOLE:** Ein lokales Gravitationsfeld zieht Asteroiden in sein Zentrum.
- **Smart Triggers (Stats Module):**
    - **Combo Spawn:** Based on kill rate. Increment combo by 1 per kill if time since the previous kill is `< 3000ms`.
    - **Near-Miss Trigger:** If the player survives 3 close encounters with asteroids, an **EMP_WAVE** is spawned as a rescue.
    - **Accuracy Reward:** At > 80% accuracy, **WINGMAN_DRONES** appear.
    - **Pity Spawn:** Guarantees a power-up after 60 seconds of inactivity.
- **Hardware VFX:** EMP and Black Hole use glow effects on high-end desktop systems (e.g., P2000-class GPUs), while on mobile they are rendered as performant line vectors. Selection is a heuristic based on renderer and desktop flags, not explicit GPU detection.

### 11. Arcade Simulation & Shaders
The game is transformed into an authentic arcade experience.

- **Attract Mode:** A new entry scene simulates waiting for a coin insert ('INSERT COIN'), including a synthetic coin sound and credit system.
- **CRT Post-Processing Shader:**
    - **Scanlines:** Recreates the look of an old CRT.
    - **Curvature:** Distorts the image edges for the 3D feel of a curved monitor.
    - **Chromatic Aberration:** Simulates RGB edge fringing.
    - **Coverage:** Applied to gameplay, attract, pause, and game over screens (not the physical bezel).
    - **Hardware Fallback:** Full effect on high-end desktop systems (e.g., P2000-class GPUs); on mobile, curvature is disabled to reduce GPU load. Selection is heuristic-based.
- **Highscore Name Entry:** New high scores allow players to enter 3-letter initials via arcade controls (arrows + fire). Data is stored in structured form in `localStorage`.
- **GameOver Leaderboard Loop:** The Game Over screen renders the Top-5 list from `localStorage`, highlights newly qualified scores, and routes players through a coin-continue flow (first input inserts credit + coin sound, second input restarts). After 20 seconds of inactivity, the game returns to the Attract screen.

### 12. Performance & VFX Fallbacks
To ensure optimal play on all devices (from high-end desktops like P2000-class machines to smartphones), the game uses a pragmatic hardware fallback heuristic.

- **Slow-Motion Effect:**
    - **Desktop (WebGL):** Use a `ColorMatrix` shader (`PostFX`) that shifts the palette into a cool, desaturated blue ("Night Mode") for a sci-fi atmosphere.
    - **Mobile:** Use a simple, semi-transparent blue rectangle overlay to achieve a similar look with minimal cost (no shader pass), preserving battery and framerate.
- **Detection:** The decision is made at runtime based on `game.device.os.desktop` and the active renderer.

### 13. Physical Bezel & Real-time Reflections
A dedicated overlay scene adds a physical CRT frame around the game, without affecting the CRT shader on the gameplay layer.

- **Scene Layering:** `BezelScene` starts before `MainScene` and renders above it, ensuring the bezel stays sharp while the CRT shader only affects the gameplay scene.
- **Procedural Bezel:** The frame is drawn with `Phaser.GameObjects.Graphics`, filling the viewport and erasing the 1000x1000 playfield window. Screws and subtle plastic noise are added for authenticity.
- **Real-time Reflections (High-End):** A `RenderTexture` captures `MainScene` each frame, applies a strong blur and dimming, and is masked to the inner rim to simulate screen glow on the plastic.
- **Responsive Fit:** The bezel scales to the browser viewport, while the hole aligns precisely to the FIT-scaled 1000x1000 play area.

### 14. Attract Mode & Demo-Loop
The attract screen is a playable-looking demo loop to add life and showcase features.

- **Arcade Flow:** The attract screen runs continuously with animated UI, demo asteroids, and quick preview elements to drive player curiosity.
- **Background Asteroids:** `EnemyManager` runs in `AttractScene`, continuously spawning asteroids that drift behind the UI. Periodic scripted splits call `splitAsteroid` to demonstrate fragmenting behavior without player input.
- **Recycling:** Asteroids are pooled via the group; off-screen sprites call `disableBody(true, true)` and are reused for subsequent spawns.
- **Ambient Depth:** A subtle dust particle stream provides constant parallax-like motion.
- **UI Showcase:** Heartbeat-style pulsing text alternates with a fading Top-5 high-score table, plus a row of power-up icons labeled "COLLECT THESE!" to preview gameplay rewards.

### 15. Help System
A dedicated Help screen provides compact, scrollable guidance without breaking the CRT presentation.

- **Access:** Press `H` from the Attract screen, in-game HUD, or the Game Over screen. The `H` icon also opens it.
- **Exit:** Press `H` again or click the `Back` button to return to the previous screen.
- **Content:** Controls, power-ups, heat management, and scoring are summarized in a scrollable, masked panel.

### 16. Credits & Turn-Based Multiplayer
Classic arcade credits and a two-player alternating flow keep the game loop authentic and competitive.

- **Credit Manager:** Global credits persist across scenes. Press `I` or click the on-screen "INSERT COIN (I)" text to add credits. Start buttons consume 1 credit for 1P or 2 credits for 2P.
- **2-Player Turn System:** Each player has their own score, lives, and active power-ups. When a life is lost, gameplay pauses briefly, a "PLAYER X GET READY" overlay appears, and control swaps after 2 seconds.
- **End Condition:** The run ends only when both players are out of lives. Game Over shows both final scores and allows immediate 1P/2P restart with credits.
