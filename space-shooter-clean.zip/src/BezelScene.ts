import Phaser from 'phaser';
import { GAME_SIZE } from './gameConfig';

type PlayArea = {
  x: number;
  y: number;
  size: number;
  scale: number;
};

export default class BezelScene extends Phaser.Scene {
  private frameGraphics!: Phaser.GameObjects.Graphics;
  private reflectionRT: Phaser.GameObjects.RenderTexture | null = null;
  private reflectionMaskGraphics!: Phaser.GameObjects.Graphics;
  private reflectionMask: Phaser.Display.Masks.GeometryMask | null = null;
  private useReflection: boolean = false;
  private playArea: PlayArea = { x: 0, y: 0, size: GAME_SIZE, scale: 1 };
  private bezelThickness: number = 32;

  constructor() {
    super('BezelScene');
  }

  create() {
    this.frameGraphics = this.add.graphics();
    this.frameGraphics.setDepth(1000);
    this.reflectionMaskGraphics = this.add.graphics();
    this.reflectionMaskGraphics.setVisible(false);

    this.useReflection = this.game.device.os.desktop && this.game.renderer.type === Phaser.WEBGL;

    if (this.useReflection) {
      this.reflectionRT = this.add.renderTexture(0, 0, GAME_SIZE, GAME_SIZE);
      this.reflectionRT.setOrigin(0, 0);
      this.reflectionRT.setAlpha(0.22);
      this.reflectionRT.setTint(0x888888);
      this.reflectionRT.initPostPipeline(true);
      this.reflectionRT.preFX?.addBlur(2, 8, 8, 1.5, 0x000000, 6);
      this.reflectionRT.setDepth(1001);
    }

    this.refreshLayout();
    this.scale.on('resize', this.refreshLayout, this);
    this.events.once('shutdown', () => {
      this.scale.off('resize', this.refreshLayout, this);
      this.reflectionRT?.clear();
    });

    this.scene.bringToTop('BezelScene');
  }

  update() {
    if (!this.useReflection || !this.reflectionRT) return;
    const mainScene = this.scene.get('MainScene');
    if (!mainScene || !mainScene.scene.isActive()) {
      this.reflectionRT.clear();
      return;
    }
    this.reflectionRT.clear();
    this.reflectionRT.draw(mainScene.children.list);
  }

  private refreshLayout() {
    const width = this.scale.width;
    const height = this.scale.height;
    const scale = Math.min(width / GAME_SIZE, height / GAME_SIZE);
    const size = GAME_SIZE * scale;
    const x = (width - size) / 2;
    const y = (height - size) / 2;

    this.playArea = { x, y, size, scale };
    this.bezelThickness = Math.max(4, Math.round(size * 0.004));
    this.drawFrame();

    if (this.reflectionRT) {
      this.reflectionRT.setPosition(x, y);
      this.reflectionRT.setScale(scale);
      this.updateReflectionMask();
    }
  }

  private drawFrame() {
    const { x, y, size } = this.playArea;
    const g = this.frameGraphics;
    g.clear();

    g.lineStyle(this.bezelThickness, 0xffffff, 1);
    g.strokeRect(x, y, size, size);
  }

  private updateReflectionMask() {
    if (!this.reflectionRT) return;
    const { x, y, size } = this.playArea;
    const border = this.bezelThickness;
    const g = this.reflectionMaskGraphics;
    g.clear();
    g.fillStyle(0xffffff, 1);
    g.fillRect(x, y, size, size);
    g.setBlendMode(Phaser.BlendModes.ERASE);
    g.fillRect(x + border, y + border, size - border * 2, size - border * 2);
    g.setBlendMode(Phaser.BlendModes.NORMAL);

    if (!this.reflectionMask) {
      this.reflectionMask = g.createGeometryMask();
      this.reflectionRT.setMask(this.reflectionMask);
    }
  }
}
