import Phaser from 'phaser';
import { GAME_SIZE } from './gameConfig';
import MainScene from './MainScene';

export default class PauseScene extends Phaser.Scene {
  constructor() {
    super('PauseScene');
  }

  create() {
    const centerX = GAME_SIZE / 2;
    const centerY = GAME_SIZE / 2;

    if (!this.scene.isActive('BezelScene')) {
      this.scene.launch('BezelScene');
    }
    this.scene.bringToTop('BezelScene');

    if (this.game.renderer instanceof Phaser.Renderer.WebGL.WebGLRenderer) {
      this.cameras.main.setPostPipeline('CRTPipeline');
    }

    // Semi-transparent overlay
    const overlay = this.add.rectangle(centerX, centerY, GAME_SIZE, GAME_SIZE, 0x000000, 0.7);
    overlay.setInteractive(); // Prevent clicks passing through

    // PAUSED Text
    this.add
      .text(centerX, centerY - 100, 'PAUSED', {
        fontFamily: '"Press Start 2P"',
        fontSize: '64px',
        color: '#ffffff',
      })
      .setOrigin(0.5);

    // RESUME Button Background
    const btnWidth = 350;
    const btnHeight = 80;
    const btnY = centerY + 50;

    const resumeBtn = this.add
      .rectangle(centerX, btnY, btnWidth, btnHeight, 0x00cc00)
      .setInteractive({ useHandCursor: true });

    this.add
      .text(centerX, btnY, 'RESUME', {
        fontFamily: '"Press Start 2P"',
        fontSize: '24px',
        color: '#ffffff',
      })
      .setOrigin(0.5);

    // Resume Logic
    const resumeGame = () => {
      const mainScene = this.scene.get('MainScene') as MainScene;
      mainScene.audio.resumeAll();
      this.scene.stop();
      this.scene.resume('MainScene');
    };

    resumeBtn.on('pointerdown', resumeGame);

    // Keyboard support
    this.input.keyboard?.on('keydown-P', resumeGame);
    this.input.keyboard?.on('keydown-ESC', resumeGame);

    // Pulsing effect for button
    this.tweens.add({
      targets: resumeBtn,
      alpha: 0.8,
      duration: 500,
      yoyo: true,
      repeat: -1,
    });
  }
}
